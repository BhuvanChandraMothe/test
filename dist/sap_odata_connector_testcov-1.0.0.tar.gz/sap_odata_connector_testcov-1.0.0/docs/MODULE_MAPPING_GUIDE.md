# SAP Module Mapping Guide

## Overview

The SAP OData Connector now supports **automatic URL construction** from SAP module names. Instead of manually constructing the full OData service URL, you can simply specify the SAP module (e.g., `FI`, `MM`, `ARIBA`, `ES5`) and the connector will automatically map it to the correct OData service name and build the URL.

## Features

✅ **50+ Pre-configured SAP Modules** - Finance, Logistics, HR, Cloud services, and more  
✅ **Automatic URL Construction** - Just provide server + module name  
✅ **Credential Validation** - Tests connection via metadata endpoint  
✅ **Backward Compatible** - Legacy direct URL mode still works  
✅ **Auto-detection** - Detects module names even in `service_name` field  

---

## How It Works

### SAP OData URL Structure

Standard SAP OData URLs follow this pattern:
```
https://<SERVER>:<PORT>/sap/opu/odata/sap/<SERVICE_NAME>
```

For example:
```
https://sapes5.sapdevcenter.com:443/sap/opu/odata/sap/EPM_REF_APPS_SHOP_SRV
```

### The Problem

Previously, you had to:
1. Know the exact OData service name (e.g., `EPM_REF_APPS_SHOP_SRV`)
2. Manually construct the full URL
3. Remember different service names for different modules

### The Solution

Now you can simply use the module name:
```python
config = ClientConfig(
    sap_server="sapes5.sapdevcenter.com",
    sap_port=443,
    sap_module="ES5",  # Automatically mapped to EPM_REF_APPS_SHOP_SRV
    username="your_username",
    password="your_password"
)
```

---

## Configuration Methods

### Method 1: Module-Based Configuration (NEW! ⭐)

Use the `sap_module` parameter to specify the SAP module:

```python
from odc.config.models import ClientConfig
from odc.connector import SAPODataConnector

config = ClientConfig(
    sap_server="sapes5.sapdevcenter.com",
    sap_port=443,
    sap_module="ES5",  # Module name
    use_https=True,
    username="your_username",
    password="your_password",
    output_directory="./output"
)

connector = SAPODataConnector(config)
```

**Supported modules:** `FI`, `MM`, `SD`, `HR`, `ARIBA`, `CONCUR`, `ES5`, and 40+ more!

### Method 2: Auto-Detection in service_name

Even if you put a module name in the `service_name` field, it will be auto-detected:

```python
config = ClientConfig(
    sap_server="sapes5.sapdevcenter.com",
    sap_port=443,
    service_name="ES5",  # Will be detected as module and mapped
    username="your_username",
    password="your_password"
)
```

### Method 3: Manual Service Name

Provide the exact OData service name:

```python
config = ClientConfig(
    sap_server="sapes5.sapdevcenter.com",
    sap_port=443,
    service_name="EPM_REF_APPS_SHOP_SRV",  # Direct service name
    username="your_username",
    password="your_password"
)
```

### Method 4: Legacy Direct URL

Backward compatible with direct URL:

```python
config = ClientConfig(
    service_url="https://sapes5.sapdevcenter.com/sap/opu/odata/sap/EPM_REF_APPS_SHOP_SRV/",
    username="your_username",
    password="your_password"
)
```

---

## Supported SAP Modules

### Finance Modules
| Module | Service Name | Description |
|--------|-------------|-------------|
| `FI` | `FINS_GENERALLEDGER_SRV` | Financial Accounting - General Ledger |
| `FI-GL` | `FINS_GENERALLEDGER_SRV` | General Ledger |
| `FI-AP` | `FINS_ACCOUNTSPAYABLE_SRV` | Accounts Payable |
| `FI-AR` | `FINS_ACCOUNTSRECEIVABLE_SRV` | Accounts Receivable |
| `FI-AA` | `FINS_FIXEDASSETS_SRV` | Fixed Assets |
| `CO` | `FINS_CONTROLLING_SRV` | Controlling |
| `CO-PA` | `FINS_PROFITABILITY_SRV` | Profitability Analysis |

### Logistics Modules
| Module | Service Name | Description |
|--------|-------------|-------------|
| `MM` | `MM_PUR_PO_MAINT_V2_SRV` | Materials Management |
| `MM-PUR` | `MM_PUR_PO_MAINT_V2_SRV` | Purchasing |
| `MM-IM` | `MM_IM_STOCK_SRV` | Inventory Management |
| `SD` | `SD_F1814_SO_SALESORDER_SRV` | Sales & Distribution |
| `SD-SO` | `SD_F1814_SO_SALESORDER_SRV` | Sales Orders |
| `PP` | `PP_PRODUCTION_ORDER_SRV` | Production Planning |

### Human Resources
| Module | Service Name | Description |
|--------|-------------|-------------|
| `HR` | `HCM_EMPLOYEE_SRV` | Human Capital Management |
| `HR-PA` | `HCM_PERSONNEL_SRV` | Personnel Administration |
| `SF` | `SUCCESSFACTORS_EMPLOYEE_SRV` | SuccessFactors |
| `SUCCESSFACTORS` | `SUCCESSFACTORS_EMPLOYEE_SRV` | SuccessFactors Employee |

### Cloud Services
| Module | Service Name | Description |
|--------|-------------|-------------|
| `ARIBA` | `ARIBA_PROCUREMENT_SRV` | Ariba Procurement |
| `ARIBA-BUYER` | `ARIBA_BUYER_SRV` | Ariba Buyer |
| `ARIBA-SUPPLIER` | `ARIBA_SUPPLIER_SRV` | Ariba Supplier |
| `CONCUR` | `CONCUR_EXPENSE_SRV` | Concur Expense Management |
| `CONCUR-TRAVEL` | `CONCUR_TRAVEL_SRV` | Concur Travel |

### Demo/Testing Systems
| Module | Service Name | Description |
|--------|-------------|-------------|
| `ES5` | `EPM_REF_APPS_SHOP_SRV` | ES5 Demo System (SAP Gateway) |
| `EPM` | `EPM_REF_APPS_SHOP_SRV` | Enterprise Procurement Model |
| `EPM-SHOP` | `EPM_REF_APPS_SHOP_SRV` | EPM Shop Demo |
| `DEMO` | `ZGWSAMPLE_BASIC` | Gateway Sample Service |

**Total:** 50+ modules supported! See `sap_module_mapping.py` for the complete list.

---

## Connection Testing

The connector automatically validates credentials by testing the metadata endpoint:

```python
async def test_connection():
    config = ClientConfig(
        sap_server="sapes5.sapdevcenter.com",
        sap_port=443,
        sap_module="ES5",
        username="your_username",
        password="your_password"
    )
    
    connector = SAPODataConnector(config)
    
    try:
        # This will test the connection and validate credentials
        await connector.initialize()
        print("✅ Connection successful!")
        print("✅ Credentials validated!")
    except ConnectionError as e:
        print(f"❌ Connection failed: {e}")
    finally:
        await connector.cleanup()
```

### What Happens During Connection Test?

1. **URL Construction** - Module name is mapped to service name
2. **Metadata Request** - GET request to `$metadata` endpoint
3. **Authentication** - Basic auth with provided credentials
4. **Status Validation** - Checks HTTP status codes:
   - `200` ✅ Success
   - `401` ❌ Invalid credentials
   - `403` ❌ Access forbidden
   - `404` ❌ Service not found

---

## Module Discovery

### Get Module Information

```python
from odc.config.sap_module_mapping import SAPModuleMapping

# Get service name for a module
service_name = SAPModuleMapping.get_service_name("ES5")
print(service_name)  # EPM_REF_APPS_SHOP_SRV

# Get detailed module info
info = SAPModuleMapping.get_module_info("ARIBA")
print(info)
# {
#     'module_name': 'ARIBA',
#     'service_name': 'ARIBA_PROCUREMENT_SRV',
#     'category': 'procurement',
#     'is_cloud': True,
#     'is_demo': False
# }
```

### List All Modules

```python
all_modules = SAPModuleMapping.get_all_modules()
print(f"Total modules: {len(all_modules)}")
print(all_modules[:10])  # First 10 modules
```

### Search Modules

```python
# Search for finance modules
finance_modules = SAPModuleMapping.search_modules("FI")
print(finance_modules)
# ['FI', 'FI-GL', 'FI-AP', 'FI-AR', 'FI-AA', 'FI-BL', 'FI-CA', 'S4-FI']

# Search for Ariba modules
ariba_modules = SAPModuleMapping.search_modules("ARIBA")
print(ariba_modules)
# ['ARIBA', 'ARIBA-BUYER', 'ARIBA-SUPPLIER', 'ARIBA-CONTRACT', 'ARIBA-SOURCING']
```

### Check Module Validity

```python
is_valid = SAPModuleMapping.is_valid_module("ES5")
print(is_valid)  # True

is_valid = SAPModuleMapping.is_valid_module("INVALID_MODULE")
print(is_valid)  # False
```

---

## Complete Example: ES5 Demo System

```python
import asyncio
from odc.config.models import ClientConfig
from odc.connector import SAPODataConnector

async def es5_demo():
    # Configure using ES5 module
    config = ClientConfig(
        sap_server="sapes5.sapdevcenter.com",
        sap_port=443,
        sap_module="ES5",  # Automatically mapped to EPM_REF_APPS_SHOP_SRV
        use_https=True,
        username="YOUR_ES5_USERNAME",
        password="YOUR_ES5_PASSWORD",
        output_directory="./output_es5"
    )
    
    # Create connector
    connector = SAPODataConnector(config)
    
    try:
        # Initialize (tests connection and validates credentials)
        print("Initializing connector...")
        await connector.initialize()
        print("✅ Connection successful!")
        
        # Get products
        print("\nFetching products...")
        result = await connector.get_data(
            entity_name="Products",
            select_fields="Id,Name,Price,CurrencyCode",
            record_limit=10
        )
        
        print(f"✅ Retrieved {result['execution_stats']['records_processed']} products")
        
        # Get reviews with filter
        print("\nFetching recent reviews...")
        result = await connector.get_data(
            entity_name="Reviews",
            filter_condition="Rating ge 4",
            select_fields="Id,Rating,Comment,ProductId",
            order_by="ChangedAt desc",
            record_limit=5
        )
        
        print(f"✅ Retrieved {result['execution_stats']['records_processed']} reviews")
        
    finally:
        await connector.cleanup()

# Run the demo
asyncio.run(es5_demo())
```

---

## Advanced Features

### SAP Client Parameter

For SAP systems that require a client number:

```python
config = ClientConfig(
    sap_server="your-sap-server.com",
    sap_port=8000,
    sap_module="FI",
    sap_client="100",  # SAP client number
    username="your_username",
    password="your_password"
)

# URL will be: https://your-sap-server.com:8000/sap/opu/odata/sap/FINS_GENERALLEDGER_SRV?sap-client=100
```

### Custom Service Names

If your SAP system uses custom service names not in the mapping:

```python
config = ClientConfig(
    sap_server="your-sap-server.com",
    sap_port=8000,
    service_name="ZMY_CUSTOM_SERVICE_SRV",  # Custom service
    username="your_username",
    password="your_password"
)
```

### HTTP vs HTTPS

```python
config = ClientConfig(
    sap_server="internal-sap-server",
    sap_port=8000,
    sap_module="FI",
    use_https=False,  # Use HTTP instead of HTTPS
    username="your_username",
    password="your_password"
)
```

---

## Error Handling

### Invalid Module Name

```python
config = ClientConfig(
    sap_server="server.com",
    sap_port=443,
    sap_module="INVALID_MODULE",  # Not in mapping
    username="user",
    password="pass"
)

# Warning will be logged, module name will be used as-is
# URL: https://server.com:443/sap/opu/odata/sap/INVALID_MODULE
```

### Missing Configuration

```python
try:
    config = ClientConfig(
        sap_server="server.com",
        sap_port=443,
        # Missing: sap_module or service_name
        username="user",
        password="pass"
    )
    config.validate()
except ValueError as e:
    print(f"Configuration error: {e}")
    # Error: Either service_name or sap_module must be provided
```

### Connection Failures

```python
try:
    await connector.initialize()
except ConnectionError as e:
    print(f"Connection failed: {e}")
    # Possible reasons:
    # - Invalid credentials (401)
    # - Service not found (404)
    # - Network issues
    # - Wrong server/port
```

---

## Migration Guide

### From Direct URL to Module Mapping

**Before:**
```python
config = ClientConfig(
    service_url="https://sapes5.sapdevcenter.com/sap/opu/odata/sap/EPM_REF_APPS_SHOP_SRV/",
    username="user",
    password="pass"
)
```

**After:**
```python
config = ClientConfig(
    sap_server="sapes5.sapdevcenter.com",
    sap_port=443,
    sap_module="ES5",  # Much simpler!
    username="user",
    password="pass"
)
```

---

## Testing

Run the module mapping tests:

```bash
# Test module mapping functionality
python test_module_mapping.py

# View examples
python examples/module_based_config_examples.py
```

---

## API Reference

### SAPModuleMapping Class

```python
from odc.config.sap_module_mapping import SAPModuleMapping

# Get service name for module
service_name = SAPModuleMapping.get_service_name(module_name: str) -> Optional[str]

# Get module information
info = SAPModuleMapping.get_module_info(module_name: str) -> Optional[Dict]

# Check if module is valid
is_valid = SAPModuleMapping.is_valid_module(module_name: str) -> bool

# Get all supported modules
modules = SAPModuleMapping.get_all_modules() -> List[str]

# Search for modules
results = SAPModuleMapping.search_modules(search_term: str) -> List[str]

# Get modules by category
modules = SAPModuleMapping.get_modules_by_category(category: SAPModuleCategory) -> List[str]
```

### ClientConfig Updates

```python
config = ClientConfig(
    # New parameters
    sap_module: Optional[str] = None,  # SAP module name (e.g., 'FI', 'ES5')
    
    # Updated parameters
    service_name: Optional[str] = None,  # Now accepts module names too
    
    # Existing parameters
    sap_server: Optional[str] = None,
    sap_port: int = 8000,
    sap_client: Optional[str] = None,
    use_https: bool = True,
    username: Optional[str] = None,
    password: Optional[str] = None,
    service_url: Optional[str] = None,  # Legacy mode
)

# New methods
config.get_module_info() -> Optional[Dict]
```

---

## FAQ

**Q: What if my module is not in the mapping?**  
A: The connector will use your module name as the service name directly. You can also add custom mappings to `sap_module_mapping.py`.

**Q: Can I still use direct URLs?**  
A: Yes! The legacy `service_url` parameter still works for backward compatibility.

**Q: How do I know which module to use?**  
A: Use `SAPModuleMapping.get_all_modules()` to see all supported modules, or search with `search_modules()`.

**Q: Does this work with custom SAP services?**  
A: Yes, use the `service_name` parameter directly with your custom service name.

**Q: How is the connection tested?**  
A: The connector makes a GET request to the `$metadata` endpoint with your credentials to validate the connection.

---

## Contributing

To add new module mappings, edit `odc/config/sap_module_mapping.py`:

```python
MODULE_TO_SERVICE: Dict[str, str] = {
    # Add your module here
    "MY-MODULE": "MY_ODATA_SERVICE_SRV",
}
```

---

## Support

For issues or questions:
- Check the examples: `examples/module_based_config_examples.py`
- Run tests: `test_module_mapping.py`
- Review the mapping: `odc/config/sap_module_mapping.py`

---

**Last Updated:** 2025-10-06  
**Version:** 2.0.0
